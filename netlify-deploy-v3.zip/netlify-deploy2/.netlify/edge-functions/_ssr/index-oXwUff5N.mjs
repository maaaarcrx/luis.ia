import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { S as SiteHeader } from "./SiteHeader-T_rHV__Y.mjs";
import { S as SiteFooter } from "./SiteFooter-Bu54eDjk.mjs";
import { d as useNavigate, L as Link, u as useRouter } from "../_libs/tanstack__react-router.mjs";
import { m as isRedirect } from "../_libs/tanstack__router-core.mjs";
import { c as createSsrRpc, v as valorarVivienda } from "./router-GROOodPV.mjs";
import { c as createServerFn } from "./server-C60K3KFC.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { S as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import "../_libs/seroval.mjs";
import { M as MapPin, B as Building2, S as Sparkles, a as ShieldCheck, T as TrendingUp, F as FileText, H as House, C as Check, L as LoaderCircle, b as Search, A as ArrowLeft, c as ArrowRight } from "../_libs/lucide-react.mjs";
import { m as motion, A as AnimatePresence } from "../_libs/framer-motion.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./valuation-CXMPruSL.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function useServerFn(serverFn) {
  const router = useRouter();
  return reactExports.useCallback(async (...args) => {
    try {
      const res = await serverFn(...args);
      if (isRedirect(res)) throw res;
      return res;
    } catch (err) {
      if (isRedirect(err)) {
        err.options._fromLocation = router.stores.location.get();
        return router.navigate(router.resolveRedirect(err).options);
      }
      throw err;
    }
  }, [router, serverFn]);
}
const buscarDirecciones = createServerFn({
  method: "GET"
}).inputValidator((data) => objectType({
  q: stringType().min(3).max(120)
}).parse(data)).handler(createSsrRpc("810aa22c1d1bb83e12f41fa3cb65de7391be749566075fa1730e53daac1a76c3"));
const EXTRAS_LIST = [
  { key: "terraza", label: "Terraza", emoji: "🌿" },
  { key: "balcon", label: "Balcón", emoji: "🪟" },
  { key: "ascensor", label: "Ascensor", emoji: "🛗" },
  { key: "parking", label: "Parking", emoji: "🚗" },
  { key: "piscina", label: "Piscina", emoji: "🏊" },
  { key: "jardin", label: "Jardín", emoji: "🌳" },
  { key: "vistas", label: "Vistas", emoji: "🌅" },
  { key: "reformado", label: "Reformado", emoji: "✨" }
];
const ESTADOS = [
  { key: "nuevo", label: "Obra nueva", desc: "Vivienda recién construida o sin estrenar" },
  { key: "buen_estado", label: "Buen estado", desc: "Lista para entrar a vivir" },
  { key: "necesita_reforma", label: "A reformar", desc: "Requiere obra para habitarla" }
];
function ValuationWizard() {
  const [step, setStep] = reactExports.useState(1);
  const [loading, setLoading] = reactExports.useState(false);
  const navigate = useNavigate();
  const valorar = useServerFn(valorarVivienda);
  const buscarDirs = useServerFn(buscarDirecciones);
  const [form, setForm] = reactExports.useState({
    direccion: "",
    ciudad: "",
    codigoPostal: "",
    metrosCuadrados: 90,
    habitaciones: 3,
    banos: 2,
    planta: 2,
    anoConstruccion: 1990,
    estado: "buen_estado",
    extras: {}
  });
  const [suggestions, setSuggestions] = reactExports.useState([]);
  const [searching, setSearching] = reactExports.useState(false);
  const [showSugg, setShowSugg] = reactExports.useState(false);
  const [selected, setSelected] = reactExports.useState(false);
  const debounceRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    if (selected) return;
    const q = form.direccion.trim();
    if (q.length < 4) {
      setSuggestions([]);
      return;
    }
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const { results } = await buscarDirs({ data: { q } });
        setSuggestions(results);
        setShowSugg(true);
      } catch (e) {
        console.error(e);
      } finally {
        setSearching(false);
      }
    }, 350);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [form.direccion, selected, buscarDirs]);
  const update = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const toggleExtra = (k) => setForm((f) => ({ ...f, extras: { ...f.extras, [k]: !f.extras[k] } }));
  const pickSuggestion = (s) => {
    setSelected(true);
    setShowSugg(false);
    setForm((f) => ({
      ...f,
      direccion: s.label,
      ciudad: s.ciudad || f.ciudad,
      codigoPostal: s.codigoPostal || f.codigoPostal
    }));
  };
  const canNext = () => {
    if (step === 1) return form.direccion.trim().length > 3;
    if (step === 2) return form.metrosCuadrados >= 15;
    return true;
  };
  const submit = async () => {
    setLoading(true);
    try {
      const result = await valorar({
        data: {
          direccion: form.direccion,
          ciudad: form.ciudad || null,
          codigoPostal: form.codigoPostal || null,
          metrosCuadrados: form.metrosCuadrados,
          habitaciones: form.habitaciones,
          banos: form.banos,
          planta: form.planta,
          anoConstruccion: form.anoConstruccion,
          estado: form.estado,
          extras: form.extras
        }
      });
      if (!result.id) {
        toast.error("No pudimos guardar la valoración.");
        return;
      }
      navigate({ to: "/resultado/$id", params: { id: result.id } });
    } catch (e) {
      console.error(e);
      toast.error("Ocurrió un error al calcular la valoración.");
    } finally {
      setLoading(false);
    }
  };
  const steps = [
    { n: 1, label: "Ubicación", icon: MapPin },
    { n: 2, label: "Datos", icon: House },
    { n: 3, label: "Estado", icon: Sparkles }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      id: "valorador",
      initial: { opacity: 0, y: 24 },
      animate: { opacity: 1, y: 0 },
      transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] },
      className: "bg-card rounded-3xl shadow-[var(--shadow-elegant)] border border-border p-6 md:p-10 relative overflow-hidden",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute -top-32 -right-32 size-72 rounded-full bg-accent/10 blur-3xl" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex justify-between mb-10 relative", children: steps.map((s, i) => {
          const active = step >= s.n;
          const done = step > s.n;
          const Icon = s.icon;
          return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center flex-1 last:flex-none", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.div,
                {
                  animate: { scale: step === s.n ? 1.1 : 1 },
                  transition: { type: "spring", stiffness: 300, damping: 20 },
                  className: `size-10 rounded-full flex items-center justify-center font-bold transition-colors ${active ? "bg-accent text-accent-foreground" : "bg-secondary text-muted-foreground"}`,
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", children: done ? /* @__PURE__ */ jsxRuntimeExports.jsx(motion.span, { initial: { scale: 0, rotate: -90 }, animate: { scale: 1, rotate: 0 }, exit: { scale: 0 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "size-4" }) }, "check") : /* @__PURE__ */ jsxRuntimeExports.jsx(motion.span, { initial: { scale: 0 }, animate: { scale: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "size-4" }) }, "icon") })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `text-[10px] md:text-xs font-semibold uppercase tracking-wider ${active ? "text-accent" : "text-muted-foreground"}`, children: s.label })
            ] }),
            i < steps.length - 1 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 h-px bg-border self-center mx-3 -mt-5 relative overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              motion.div,
              {
                className: "absolute inset-0 bg-accent origin-left",
                initial: { scaleX: 0 },
                animate: { scaleX: step > s.n ? 1 : 0 },
                transition: { duration: 0.5, ease: "easeOut" }
              }
            ) })
          ] }, s.n);
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(AnimatePresence, { mode: "wait", children: [
          step === 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: { opacity: 0, x: 30 }, animate: { opacity: 1, x: 0 }, exit: { opacity: 0, x: -30 }, transition: { duration: 0.3 }, className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold mb-2", children: "Dirección de la vivienda" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none", children: searching ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-5 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "size-5" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    autoFocus: true,
                    value: form.direccion,
                    onChange: (e) => {
                      setSelected(false);
                      update("direccion", e.target.value);
                    },
                    onFocus: () => suggestions.length > 0 && setShowSugg(true),
                    onBlur: () => setTimeout(() => setShowSugg(false), 200),
                    placeholder: "Calle de Velázquez 24, Madrid…",
                    className: "w-full pl-12 pr-5 py-4 bg-secondary border border-border rounded-2xl focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent text-base md:text-lg transition-all"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: showSugg && suggestions.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.ul,
                {
                  initial: { opacity: 0, y: -8 },
                  animate: { opacity: 1, y: 0 },
                  exit: { opacity: 0, y: -8 },
                  transition: { duration: 0.18 },
                  className: "absolute z-20 left-0 right-0 mt-2 bg-popover border border-border rounded-2xl shadow-[var(--shadow-elegant)] overflow-hidden max-h-80 overflow-y-auto",
                  children: suggestions.map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                    motion.li,
                    {
                      initial: { opacity: 0, x: -8 },
                      animate: { opacity: 1, x: 0 },
                      transition: { delay: i * 0.03 },
                      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                        "button",
                        {
                          type: "button",
                          onMouseDown: (e) => e.preventDefault(),
                          onClick: () => pickSuggestion(s),
                          className: "w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-secondary transition-colors border-b border-border last:border-0",
                          children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "size-4 text-accent shrink-0 mt-0.5" }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold truncate", children: s.label }),
                              s.codigoPostal && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
                                "CP ",
                                s.codigoPostal
                              ] })
                            ] })
                          ]
                        }
                      )
                    },
                    `${s.label}-${i}`
                  ))
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold mb-2", children: "Ciudad" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    value: form.ciudad,
                    onChange: (e) => update("ciudad", e.target.value),
                    placeholder: "Madrid, Barcelona…",
                    className: "w-full px-4 py-3 bg-secondary border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/30"
                  }
                )
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-semibold mb-2", children: "Código postal" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "text",
                    inputMode: "numeric",
                    maxLength: 5,
                    value: form.codigoPostal,
                    onChange: (e) => update("codigoPostal", e.target.value.replace(/\D/g, "")),
                    placeholder: "28013",
                    className: "w-full px-4 py-3 bg-secondary border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/30"
                  }
                )
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "size-3 text-accent" }),
              "Buscamos en todas las calles de España (OpenStreetMap) y los precios se actualizan con IA."
            ] })
          ] }, "s1"),
          step === 2 && /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: { opacity: 0, x: 30 }, animate: { opacity: 1, x: 0 }, exit: { opacity: 0, x: -30 }, transition: { duration: 0.3 }, className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(NumberField, { label: "m²", value: form.metrosCuadrados, min: 15, max: 2e3, onChange: (v) => update("metrosCuadrados", v) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(NumberField, { label: "Habitaciones", value: form.habitaciones, min: 0, max: 15, onChange: (v) => update("habitaciones", v) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(NumberField, { label: "Baños", value: form.banos, min: 0, max: 10, onChange: (v) => update("banos", v) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(NumberField, { label: "Planta", value: form.planta, min: 0, max: 60, onChange: (v) => update("planta", v) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-xs", children: /* @__PURE__ */ jsxRuntimeExports.jsx(NumberField, { label: "Año de construcción", value: form.anoConstruccion, min: 1800, max: (/* @__PURE__ */ new Date()).getFullYear() + 2, onChange: (v) => update("anoConstruccion", v) }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold mb-3", children: "Extras y características" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 md:grid-cols-4 gap-2", children: EXTRAS_LIST.map((x, i) => {
                const on = form.extras[x.key];
                return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                  motion.button,
                  {
                    type: "button",
                    onClick: () => toggleExtra(x.key),
                    initial: { opacity: 0, y: 8 },
                    animate: { opacity: 1, y: 0 },
                    transition: { delay: i * 0.03 },
                    whileHover: { y: -2 },
                    whileTap: { scale: 0.96 },
                    className: `px-3 py-2.5 rounded-xl border text-sm font-medium transition-colors flex items-center gap-2 ${on ? "bg-accent text-accent-foreground border-accent" : "bg-secondary border-border hover:border-foreground/20"}`,
                    children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: x.emoji }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: x.label })
                    ]
                  },
                  x.key
                );
              }) })
            ] })
          ] }, "s2"),
          step === 3 && /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: { opacity: 0, x: 30 }, animate: { opacity: 1, x: 0 }, exit: { opacity: 0, x: -30 }, transition: { duration: 0.3 }, className: "space-y-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold", children: "¿Cuál es el estado de la vivienda?" }),
            ESTADOS.map((e, i) => {
              const on = form.estado === e.key;
              return /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.button,
                {
                  type: "button",
                  onClick: () => update("estado", e.key),
                  initial: { opacity: 0, y: 12 },
                  animate: { opacity: 1, y: 0 },
                  transition: { delay: i * 0.08 },
                  whileHover: { scale: 1.01 },
                  whileTap: { scale: 0.99 },
                  className: `w-full text-left p-5 rounded-2xl border transition-colors ${on ? "bg-accent/5 border-accent ring-2 ring-accent/20" : "bg-secondary border-border hover:border-foreground/20"}`,
                  children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold", children: e.label }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm text-muted-foreground", children: e.desc })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      motion.div,
                      {
                        animate: { scale: on ? 1 : 0.8 },
                        className: `size-5 rounded-full border-2 grid place-items-center ${on ? "border-accent bg-accent" : "border-border"}`,
                        children: on && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "size-3 text-accent-foreground" })
                      }
                    )
                  ] })
                },
                e.key
              );
            })
          ] }, "s3")
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-3 mt-10 relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              type: "button",
              onClick: () => setStep((s) => Math.max(1, s - 1)),
              disabled: step === 1 || loading,
              className: "px-5 py-3 rounded-xl text-sm font-semibold text-muted-foreground hover:text-foreground disabled:opacity-30 flex items-center gap-2",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "size-4" }),
                " Atrás"
              ]
            }
          ),
          step < 3 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.button,
            {
              type: "button",
              onClick: () => setStep((s) => s + 1),
              disabled: !canNext(),
              whileHover: { scale: 1.02 },
              whileTap: { scale: 0.98 },
              className: "bg-accent text-accent-foreground px-7 py-3.5 rounded-xl text-base font-bold hover:shadow-lg hover:shadow-accent/30 transition-shadow flex items-center gap-2 disabled:opacity-50",
              children: [
                "Continuar ",
                /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "size-4" })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.button,
            {
              type: "button",
              onClick: submit,
              disabled: loading,
              whileHover: { scale: 1.02 },
              whileTap: { scale: 0.98 },
              className: "relative bg-brand text-brand-foreground px-7 py-3.5 rounded-xl text-base font-bold hover:opacity-90 transition-all flex items-center gap-2 disabled:opacity-50 overflow-hidden",
              children: [
                loading && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  motion.span,
                  {
                    className: "absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent",
                    animate: { x: ["-100%", "100%"] },
                    transition: { duration: 1.4, repeat: Infinity, ease: "linear" }
                  }
                ),
                loading ? /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "size-4 animate-spin" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "size-4" }),
                loading ? "Analizando con IA…" : "Valorar con IA"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: loading && /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingOverlay, {}) })
      ]
    }
  );
}
const LOADING_MESSAGES = [
  "Localizando la vivienda en el mapa…",
  "Analizando el mercado inmobiliario de la zona…",
  "Buscando propiedades comparables cercanas…",
  "Calculando precio €/m² actualizado…",
  "Aplicando ajustes por estado y extras…",
  "Generando análisis con inteligencia artificial…"
];
function LoadingOverlay() {
  const [idx, setIdx] = reactExports.useState(0);
  reactExports.useEffect(() => {
    const id = setInterval(() => setIdx((i) => (i + 1) % LOADING_MESSAGES.length), 1400);
    return () => clearInterval(id);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    motion.div,
    {
      initial: { opacity: 0 },
      animate: { opacity: 1 },
      exit: { opacity: 0 },
      className: "absolute inset-0 bg-card/95 backdrop-blur-sm grid place-items-center z-30 rounded-3xl",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center max-w-sm px-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative size-20 mx-auto mb-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            motion.div,
            {
              className: "absolute inset-0 rounded-full border-4 border-accent/20"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            motion.div,
            {
              className: "absolute inset-0 rounded-full border-4 border-transparent border-t-accent",
              animate: { rotate: 360 },
              transition: { duration: 1, repeat: Infinity, ease: "linear" }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "absolute inset-0 m-auto size-7 text-accent" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { mode: "wait", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.p,
          {
            initial: { opacity: 0, y: 8 },
            animate: { opacity: 1, y: 0 },
            exit: { opacity: 0, y: -8 },
            transition: { duration: 0.3 },
            className: "font-semibold text-foreground",
            children: LOADING_MESSAGES[idx]
          },
          idx
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-5 flex justify-center gap-1", children: LOADING_MESSAGES.map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: `h-1 rounded-full transition-all ${i <= idx ? "bg-accent w-6" : "bg-border w-3"}`
          },
          i
        )) })
      ] })
    }
  );
}
function NumberField({
  label,
  value,
  onChange,
  min,
  max
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type: "number",
        value,
        min,
        max,
        onChange: (e) => onChange(Number(e.target.value)),
        className: "w-full px-4 py-3 bg-secondary border border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-accent/30 font-semibold transition-all"
      }
    )
  ] });
}
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
function PriceExplorerWidget() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "px-6 py-20", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-6xl mx-auto bg-slate-50 dark:bg-card rounded-[2.5rem] p-8 md:p-14 border border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid md:grid-cols-2 gap-10 md:gap-14 items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0, x: -30 },
        whileInView: { opacity: 1, x: 0 },
        viewport: { once: true },
        transition: { duration: 0.6 },
        className: "relative aspect-[4/3] rounded-3xl overflow-hidden shadow-xl",
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "absolute inset-0",
              style: {
                background: "radial-gradient(circle at 20% 30%, #22c55e 0%, transparent 35%), radial-gradient(circle at 70% 25%, #facc15 0%, transparent 40%), radial-gradient(circle at 80% 70%, #ef4444 0%, transparent 38%), radial-gradient(circle at 30% 80%, #f97316 0%, transparent 35%), linear-gradient(135deg, #dcfce7, #fef9c3, #fee2e2)"
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "absolute inset-0 opacity-30",
              style: {
                backgroundImage: "linear-gradient(rgba(255,255,255,.4) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.4) 1px, transparent 1px)",
                backgroundSize: "40px 40px"
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            motion.div,
            {
              initial: { opacity: 0, y: 20 },
              whileInView: { opacity: 1, y: 0 },
              viewport: { once: true },
              transition: { duration: 0.6, delay: 0.3 },
              className: "absolute bottom-5 left-5 right-5 md:right-auto md:w-64 bg-white rounded-2xl shadow-lg p-4",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs font-bold uppercase tracking-wider text-slate-500 mb-3", children: "Precios medios" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-8 rounded-lg bg-emerald-100 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(House, { className: "size-4 text-emerald-600" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-900", children: "2.203 € / m²" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500", children: "Vivienda" })
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-8 rounded-lg bg-blue-100 flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Building2, { className: "size-4 text-blue-600" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-bold text-slate-900", children: "3.103 € / m²" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-500", children: "Obra nueva" })
                    ] })
                  ] })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 pt-3 border-t border-slate-100", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-semibold text-slate-500 uppercase tracking-wider", children: "Evolución" }),
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] font-bold text-emerald-600 flex items-center gap-0.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "size-3" }),
                      " +4,2%"
                    ] })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 200 40", className: "w-full h-8", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("defs", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("linearGradient", { id: "lg", x1: "0", x2: "0", y1: "0", y2: "1", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "0%", stopColor: "#10b981", stopOpacity: "0.4" }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("stop", { offset: "100%", stopColor: "#10b981", stopOpacity: "0" })
                    ] }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "path",
                      {
                        d: "M0,30 L25,28 L50,25 L75,22 L100,18 L125,20 L150,14 L175,10 L200,6 L200,40 L0,40 Z",
                        fill: "url(#lg)"
                      }
                    ),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "path",
                      {
                        d: "M0,30 L25,28 L50,25 L75,22 L100,18 L125,20 L150,14 L175,10 L200,6",
                        fill: "none",
                        stroke: "#10b981",
                        strokeWidth: "2",
                        strokeLinecap: "round"
                      }
                    )
                  ] })
                ] })
              ]
            }
          )
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0, x: 30 },
        whileInView: { opacity: 1, x: 0 },
        viewport: { once: true },
        transition: { duration: 0.6 },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-accent", children: "Mapa interactivo" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight text-foreground mt-3 mb-5", children: "Explora los precios en tu zona" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground leading-relaxed mb-8", children: "Descubre el precio medio de venta y de alquiler en cada municipio. Revisa la evolución del precio a lo largo del tiempo. Navega en nuestro mapa interactivo y descubre el valor real de tu suelo." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, size: "lg", className: "rounded-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/mapa-precios", children: [
            "Mapa de precios ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "size-4" })
          ] }) })
        ]
      }
    )
  ] }) }) });
}
function Index() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "pt-16 pb-12 md:pt-24 md:pb-16 px-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary text-xs font-semibold text-muted-foreground mb-6 animate-fade-up", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "size-1.5 rounded-full bg-success animate-pulse" }),
          "Datos en directo de +50.000 viviendas en España"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-4xl md:text-6xl font-bold tracking-tight text-balance mb-6 animate-fade-up", children: [
          "Cuánto vale tu casa,",
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-accent italic", children: "al instante." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-lg text-muted-foreground max-w-2xl mx-auto mb-10 text-pretty animate-fade-up", children: "Tasación inmobiliaria gratuita con inteligencia artificial. Precio medio por m² de tu barrio, rango de valor y análisis profesional en segundos." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-3xl mx-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ValuationWizard, {}) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto mt-10 flex flex-wrap justify-center items-center gap-x-8 gap-y-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Madrid" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Barcelona" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Valencia" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Sevilla" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Bilbao" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "·" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Málaga" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "como-funciona", className: "bg-card border-y border-border py-20 px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-14", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-accent", children: "Cómo funciona" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight mt-3", children: "Una tasación seria, en 60 segundos" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-3 gap-6", children: [{
        icon: MapPin,
        title: "1. Introduces la dirección",
        desc: "Localizamos tu vivienda en nuestra base de datos por código postal y barrio."
      }, {
        icon: Building2,
        title: "2. Describes la vivienda",
        desc: "m², habitaciones, planta, año y los extras que la diferencian."
      }, {
        icon: Sparkles,
        title: "3. La IA analiza el mercado",
        desc: "Calculamos el valor con datos reales de zona y nuestro modelo lo explica."
      }].map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true,
        margin: "-80px"
      }, transition: {
        duration: 0.5,
        delay: i * 0.1
      }, whileHover: {
        y: -4
      }, className: "p-6 rounded-2xl border border-border bg-background hover:shadow-[var(--shadow-card)] transition-shadow", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-10 rounded-xl bg-accent/10 flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(f.icon, { className: "size-5 text-accent" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold mb-2", children: f.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground leading-relaxed", children: f.desc })
      ] }, f.title)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PriceExplorerWidget, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-20 px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-6xl mx-auto grid md:grid-cols-3 gap-8", children: [{
      icon: ShieldCheck,
      title: "Datos reales del mercado español",
      desc: "Trabajamos con precios medios por m² para Madrid, Barcelona, Valencia, Bilbao, Sevilla, Málaga y más."
    }, {
      icon: TrendingUp,
      title: "Rango bajo / medio / alto",
      desc: "No solo un número: te damos el margen de negociación realista para tu vivienda."
    }, {
      icon: FileText,
      title: "Explicación con IA",
      desc: "Un análisis escrito que justifica el valor y los factores que más influyen."
    }].map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 20
    }, whileInView: {
      opacity: 1,
      y: 0
    }, viewport: {
      once: true,
      margin: "-60px"
    }, transition: {
      duration: 0.5,
      delay: i * 0.1
    }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-10 rounded-xl bg-brand text-brand-foreground flex items-center justify-center mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(f.icon, { className: "size-5" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold text-lg mb-2", children: f.title }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground leading-relaxed", children: f.desc })
    ] }, f.title)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-16 px-6 bg-card border-y border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 text-center", children: [{
      n: "+50.000",
      l: "Viviendas valoradas"
    }, {
      n: "8.000",
      l: "Códigos postales"
    }, {
      n: "< 60s",
      l: "Tiempo medio"
    }, {
      n: "94%",
      l: "Precisión vs tasador"
    }].map((s, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 16
    }, whileInView: {
      opacity: 1,
      y: 0
    }, viewport: {
      once: true
    }, transition: {
      duration: 0.5,
      delay: i * 0.08
    }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl md:text-4xl font-bold tracking-tight text-accent", children: s.n }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs md:text-sm font-semibold uppercase tracking-wider text-muted-foreground mt-2", children: s.l })
    ] }, s.l)) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-20 px-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-accent", children: "Confianza" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight mt-3", children: "Lo que dicen nuestros usuarios" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid md:grid-cols-3 gap-6", children: [{
        q: "Vendí mi piso en 3 semanas al precio que Valora.IA marcó. Acertaron de pleno.",
        a: "Marta G.",
        c: "Chamberí, Madrid"
      }, {
        q: "Antes de poner el piso en venta lo comparé con dos APIs y una tasación oficial. Valora.IA fue la más cercana.",
        a: "Jordi R.",
        c: "Eixample, Barcelona"
      }, {
        q: "Súper rápido y la explicación con IA te ayuda a entender por qué tu casa vale lo que vale.",
        a: "Lucía M.",
        c: "Triana, Sevilla"
      }].map((t, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true,
        margin: "-60px"
      }, transition: {
        duration: 0.5,
        delay: i * 0.1
      }, className: "p-6 rounded-2xl border border-border bg-card", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-accent text-2xl leading-none mb-3", children: '"' }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-foreground/80 leading-relaxed text-sm mb-5", children: t.q }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-9 rounded-full bg-accent/15 grid place-items-center text-accent font-bold text-sm", children: t.a[0] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-sm", children: t.a }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: t.c })
          ] })
        ] })
      ] }, t.a)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "py-20 px-6 bg-card border-y border-border", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-accent", children: "Preguntas frecuentes" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight mt-3", children: "Todo lo que necesitas saber" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: [{
        q: "¿La valoración es gratis?",
        a: "Sí, totalmente. Puedes valorar todas las viviendas que quieras sin coste y sin registro."
      }, {
        q: "¿Qué datos usáis para calcular el precio?",
        a: "Combinamos precios medios por m² de cada barrio y código postal con un modelo que ajusta por superficie, estado, planta, año de construcción y extras."
      }, {
        q: "¿Sustituye a una tasación oficial?",
        a: "No. Es una estimación de mercado muy precisa para orientar la decisión de venta o compra, pero no sustituye a una tasación homologada para hipotecas."
      }, {
        q: "¿Cubrís toda España?",
        a: "Sí. Trabajamos con datos de todas las provincias y, cuando no tenemos una zona exacta, nuestra IA estima en base a municipio y entorno."
      }, {
        q: "¿Puedo descargar el informe?",
        a: "Sí. Al terminar la valoración recibes un informe PDF profesional con todos los detalles, listo para compartir."
      }].map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.details, { initial: {
        opacity: 0,
        y: 10
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        duration: 0.4,
        delay: i * 0.05
      }, className: "group rounded-2xl border border-border bg-background p-5 open:bg-secondary/40", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("summary", { className: "font-semibold cursor-pointer list-none flex justify-between items-center", children: [
          f.q,
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-accent text-xl transition-transform group-open:rotate-45", children: "+" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-sm text-muted-foreground leading-relaxed", children: f.a })
      ] }, f.q)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { id: "inmobiliarias", className: "py-20 px-6 bg-brand text-brand-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-4xl mx-auto text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold uppercase tracking-wider text-accent", children: "Para inmobiliarias" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl md:text-4xl font-bold tracking-tight mt-3 mb-4", children: "Tasaciones automáticas para tu agencia" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-brand-foreground/70 max-w-2xl mx-auto mb-8", children: "Marca blanca, integración con tu CRM y captación de leads cualificados de propietarios listos para vender." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href: "mailto:hola@valora.ia", className: "inline-flex items-center gap-2 bg-brand-foreground text-brand px-6 py-3 rounded-full font-bold hover:opacity-90 transition-all", children: "Hablar con ventas" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteFooter, {})
  ] });
}
export {
  Index as component
};
