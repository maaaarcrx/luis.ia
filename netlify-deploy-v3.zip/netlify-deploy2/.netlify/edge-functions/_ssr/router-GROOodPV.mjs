import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, O as Outlet, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent } from "../_libs/tanstack__react-router.mjs";
import { S as notFound } from "../_libs/tanstack__router-core.mjs";
import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { c as createServerFn, T as TSS_SERVER_FUNCTION, g as getServerFnById } from "./server-C60K3KFC.mjs";
import { f as formatEUR } from "./valuation-CXMPruSL.mjs";
import { o as objectType, s as stringType, b as booleanType, e as enumType, n as numberType } from "../_libs/zod.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
const appCss = "/assets/styles-D-OZfmxr.css";
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$3 = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Valora.IA — Tasador online de viviendas en España" },
      { name: "description", content: "Calcula cuánto vale tu casa al instante con IA. Tasación inmobiliaria gratuita basada en datos reales del mercado español." },
      { name: "theme-color", content: "#0f172a" }
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss
      }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$3.useRouteContext();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(QueryClientProvider, { client: queryClient, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) });
}
const $$splitComponentImporter$2 = () => import("./mapa-precios-IA0b7VzB.mjs");
const Route$2 = createFileRoute("/mapa-precios")({
  ssr: false,
  head: () => ({
    meta: [{
      title: "Mapa de precios del suelo en España — Valora.IA"
    }, {
      name: "description",
      content: "Mapa interactivo de precios del suelo y vivienda por zonas en España. Descubre cuánto vale tu suelo y a cuánto puedes vender."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitComponentImporter$1 = () => import("./index-oXwUff5N.mjs");
const Route$1 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Valora.IA — Tasador online de viviendas en España con IA"
    }, {
      name: "description",
      content: "Calcula cuánto vale tu casa al instante. Tasación inmobiliaria gratuita con IA basada en datos reales del mercado español: Madrid, Barcelona, Valencia y más."
    }, {
      property: "og:title",
      content: "Valora.IA — Cuánto vale tu casa, al instante"
    }, {
      property: "og:description",
      content: "Tasador online de pisos en España. Valoración gratuita con IA en segundos."
    }, {
      property: "og:type",
      content: "website"
    }, {
      name: "twitter:card",
      content: "summary_large_image"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var createSsrRpc = (functionId) => {
  const url = "/_serverFn/" + functionId;
  const serverFnMeta = { id: functionId };
  const fn = async (...args) => {
    return (await getServerFnById(functionId))(...args);
  };
  return Object.assign(fn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const Schema = objectType({
  direccion: stringType().min(3).max(255),
  ciudad: stringType().min(2).max(120).optional().nullable(),
  codigoPostal: stringType().min(4).max(10).optional().nullable(),
  metrosCuadrados: numberType().int().min(15).max(2e3),
  habitaciones: numberType().int().min(0).max(20).optional().nullable(),
  banos: numberType().int().min(0).max(15).optional().nullable(),
  planta: numberType().int().min(0).max(60).optional().nullable(),
  anoConstruccion: numberType().int().min(1800).max(2100).optional().nullable(),
  estado: enumType(["nuevo", "buen_estado", "necesita_reforma"]),
  extras: objectType({
    terraza: booleanType().optional(),
    balcon: booleanType().optional(),
    ascensor: booleanType().optional(),
    parking: booleanType().optional(),
    piscina: booleanType().optional(),
    jardin: booleanType().optional(),
    vistas: booleanType().optional(),
    reformado: booleanType().optional()
  })
});
const valorarVivienda = createServerFn({
  method: "POST"
}).inputValidator((data) => Schema.parse(data)).handler(createSsrRpc("c3c5231f854084dceeff6c7283107c36ba0c8eb96a568467804938ba786e851e"));
const obtenerValoracion = createServerFn({
  method: "GET"
}).inputValidator((data) => objectType({
  id: stringType().uuid()
}).parse(data)).handler(createSsrRpc("0569c2803ccef6f0c53e4ba230d1fb76f056f171e904a09f68dd9e04b72605d2"));
const $$splitErrorComponentImporter = () => import("./resultado._id-CfXLdQV2.mjs");
const $$splitNotFoundComponentImporter = () => import("./resultado._id-sqKTnQpw.mjs");
const $$splitComponentImporter = () => import("./resultado._id-DmARyS8B.mjs");
const Route = createFileRoute("/resultado/$id")({
  loader: async ({
    params
  }) => {
    try {
      const v = await obtenerValoracion({
        data: {
          id: params.id
        }
      });
      return {
        v
      };
    } catch {
      throw notFound();
    }
  },
  head: ({
    loaderData
  }) => ({
    meta: [{
      title: loaderData?.v ? `Valoración: ${formatEUR(Number(loaderData.v.valor_estimado_medio))} — ${loaderData.v.direccion} | Valora.IA` : "Resultado de valoración | Valora.IA"
    }, {
      name: "description",
      content: "Resultado de tu valoración inmobiliaria con IA en España."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component"),
  notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
  errorComponent: lazyRouteComponent($$splitErrorComponentImporter, "errorComponent")
});
const MapaPreciosRoute = Route$2.update({
  id: "/mapa-precios",
  path: "/mapa-precios",
  getParentRoute: () => Route$3
});
const IndexRoute = Route$1.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$3
});
const ResultadoIdRoute = Route.update({
  id: "/resultado/$id",
  path: "/resultado/$id",
  getParentRoute: () => Route$3
});
const rootRouteChildren = {
  IndexRoute,
  MapaPreciosRoute,
  ResultadoIdRoute
};
const routeTree = Route$3._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  Route as R,
  createSsrRpc as c,
  router as r,
  valorarVivienda as v
};
