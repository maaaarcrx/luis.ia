import { c as createServerRpc } from "./createServerRpc-BZVv96UL.mjs";
import { c as createServerFn } from "./server-C60K3KFC.mjs";
import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:stream";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
const buscarDirecciones_createServerFn_handler = createServerRpc({
  id: "810aa22c1d1bb83e12f41fa3cb65de7391be749566075fa1730e53daac1a76c3",
  name: "buscarDirecciones",
  filename: "src/lib/geocoding.functions.ts"
}, (opts) => buscarDirecciones.__executeServer(opts));
const buscarDirecciones = createServerFn({
  method: "GET"
}).inputValidator((data) => objectType({
  q: stringType().min(3).max(120)
}).parse(data)).handler(buscarDirecciones_createServerFn_handler, async ({
  data
}) => {
  const url = new URL("https://nominatim.openstreetmap.org/search");
  url.searchParams.set("q", data.q);
  url.searchParams.set("countrycodes", "es");
  url.searchParams.set("format", "jsonv2");
  url.searchParams.set("addressdetails", "1");
  url.searchParams.set("limit", "7");
  url.searchParams.set("accept-language", "es");
  try {
    const res = await fetch(url.toString(), {
      headers: {
        "User-Agent": "ValoraIA/1.0 (valoracion-inmuebles-espana)",
        Accept: "application/json"
      }
    });
    if (!res.ok) return {
      results: []
    };
    const json = await res.json();
    const results = json.map((r) => {
      const a = r.address ?? {};
      const calle = a.road || a.pedestrian || a.footway || "";
      const numero = a.house_number ? `, ${a.house_number}` : "";
      const ciudad = a.city || a.town || a.village || a.municipality || a.county || "";
      const cp = a.postcode || "";
      const dir = calle ? `${calle}${numero}` : r.display_name.split(",")[0];
      const label = [dir, ciudad && `${cp ? cp + " " : ""}${ciudad}`].filter(Boolean).join(", ");
      return {
        label: label || r.display_name,
        direccion: dir,
        ciudad,
        codigoPostal: cp,
        lat: Number(r.lat),
        lon: Number(r.lon)
      };
    }).filter((r) => r.direccion);
    return {
      results
    };
  } catch (e) {
    console.error("nominatim error", e);
    return {
      results: []
    };
  }
});
export {
  buscarDirecciones_createServerFn_handler
};
