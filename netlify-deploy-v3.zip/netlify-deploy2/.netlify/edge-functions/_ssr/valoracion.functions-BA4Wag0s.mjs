import { c as createServerRpc } from "./createServerRpc-BZVv96UL.mjs";
import { c as createServerFn } from "./server-C60K3KFC.mjs";
import { c as createClient } from "../_libs/supabase__supabase-js.mjs";
import { c as calcularValoracion } from "./valuation-CXMPruSL.mjs";
import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { o as objectType, b as booleanType, e as enumType, n as numberType, s as stringType } from "../_libs/zod.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:stream";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "../_libs/supabase__postgrest-js.mjs";
import "../_libs/supabase__realtime-js.mjs";
import "../_libs/supabase__phoenix.mjs";
import "../_libs/supabase__storage-js.mjs";
import "../_libs/iceberg-js.mjs";
import "../_libs/supabase__auth-js.mjs";
import "tslib";
import "../_libs/supabase__functions-js.mjs";
function createSupabaseAdminClient() {
  const SUPABASE_URL = process.env.SUPABASE_URL;
  const SUPABASE_SERVICE_ROLE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    const missing = [
      ...!SUPABASE_URL ? ["SUPABASE_URL"] : [],
      ...!SUPABASE_SERVICE_ROLE_KEY ? ["SUPABASE_SERVICE_ROLE_KEY"] : []
    ];
    const message = `Missing Supabase environment variable(s): ${missing.join(", ")}. Connect Supabase in Lovable Cloud.`;
    console.error(`[Supabase] ${message}`);
    throw new Error(message);
  }
  return createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: {
      storage: void 0,
      persistSession: false,
      autoRefreshToken: false
    }
  });
}
let _supabaseAdmin;
const supabaseAdmin = new Proxy({}, {
  get(_, prop, receiver) {
    if (!_supabaseAdmin) _supabaseAdmin = createSupabaseAdminClient();
    return Reflect.get(_supabaseAdmin, prop, receiver);
  }
});
const Schema = objectType({
  direccion: stringType().min(3).max(255),
  ciudad: stringType().min(2).max(120).optional().nullable(),
  codigoPostal: stringType().min(4).max(10).optional().nullable(),
  metrosCuadrados: numberType().int().min(15).max(2e3),
  habitaciones: numberType().int().min(0).max(20).optional().nullable(),
  banos: numberType().int().min(0).max(15).optional().nullable(),
  planta: numberType().int().min(0).max(60).optional().nullable(),
  anoConstruccion: numberType().int().min(1800).max(2100).optional().nullable(),
  estado: enumType(["nuevo", "buen_estado", "necesita_reforma"]),
  extras: objectType({
    terraza: booleanType().optional(),
    balcon: booleanType().optional(),
    ascensor: booleanType().optional(),
    parking: booleanType().optional(),
    piscina: booleanType().optional(),
    jardin: booleanType().optional(),
    vistas: booleanType().optional(),
    reformado: booleanType().optional()
  })
});
async function estimarPrecioM2ConIA(codigoPostal, ciudad) {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) return null;
  const ubic = [codigoPostal, ciudad].filter(Boolean).join(", ");
  if (!ubic) return null;
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{
          role: "system",
          content: "Eres un experto del mercado inmobiliario español 2025. Conoces precios medios €/m² de venta de vivienda por código postal, barrio y municipio (Idealista, Fotocasa, INE)."
        }, {
          role: "user",
          content: `Dame el precio medio actual de venta (€/m²) de vivienda para esta ubicación en España: "${ubic}". Si no la conoces con exactitud, estima con tu mejor criterio basándote en municipio y provincia.`
        }],
        tools: [{
          type: "function",
          function: {
            name: "precio_zona",
            description: "Devuelve precio m² estimado",
            parameters: {
              type: "object",
              properties: {
                precio_m2: {
                  type: "number"
                },
                barrio: {
                  type: "string"
                },
                ciudad: {
                  type: "string"
                }
              },
              required: ["precio_m2", "barrio", "ciudad"]
            }
          }
        }],
        tool_choice: {
          type: "function",
          function: {
            name: "precio_zona"
          }
        }
      })
    });
    if (!res.ok) return null;
    const json = await res.json();
    const args = json.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    if (!args) return null;
    const parsed = JSON.parse(args);
    const precio = Number(parsed.precio_m2);
    if (!precio || precio < 200 || precio > 2e4) return null;
    return {
      precio,
      barrio: parsed.barrio || "Zona estimada",
      ciudad: parsed.ciudad || ciudad || "España"
    };
  } catch (e) {
    console.error("estimarPrecioM2ConIA", e);
    return null;
  }
}
async function buscarZona(codigoPostal, ciudad) {
  if (codigoPostal) {
    const {
      data
    } = await supabaseAdmin.from("zonas_espana").select("*").eq("codigo_postal", codigoPostal).limit(1).maybeSingle();
    if (data) return data;
  }
  if (ciudad) {
    const {
      data
    } = await supabaseAdmin.from("zonas_espana").select("*").ilike("ciudad", ciudad).limit(50);
    if (data && data.length > 0) {
      const avg = data.reduce((s, r) => s + Number(r.precio_m2_medio), 0) / data.length;
      return {
        ...data[0],
        precio_m2_medio: avg
      };
    }
  }
  const ia = await estimarPrecioM2ConIA(codigoPostal, ciudad);
  if (ia) {
    return {
      codigo_postal: codigoPostal ?? "",
      ciudad: ia.ciudad,
      barrio: ia.barrio,
      precio_m2_medio: ia.precio
    };
  }
  return {
    codigo_postal: codigoPostal ?? "",
    ciudad: ciudad ?? "España",
    barrio: "Media nacional",
    precio_m2_medio: 2200
  };
}
async function generarExplicacion(payload) {
  const apiKey = process.env.LOVABLE_API_KEY;
  if (!apiKey) return "Análisis no disponible en este momento.";
  const sys = "Eres un analista inmobiliario senior en España. Escribe en español, en 2-3 frases máximo, sin inventar precios distintos a los que te indican. Tono profesional, claro y útil.";
  const extrasList = Object.entries(payload.extras).filter(([, v]) => v).map(([k]) => k).join(", ") || "sin extras destacables";
  const user = `Analiza esta vivienda y explica por qué su valor estimado es razonable, comparándolo con el precio medio de la zona.
- Dirección: ${payload.direccion} (${payload.ciudad}, zona ${payload.zona})
- Superficie: ${payload.m2} m²
- Estado: ${payload.estado.replace("_", " ")}
- Extras: ${extrasList}
- Precio medio de la zona: ${payload.precioM2Zona} €/m²
- Precio ajustado del inmueble: ${payload.precioM2Ajustado} €/m²
- Valor estimado: ${payload.valorMedio} €

Menciona el % de diferencia respecto a la media de la zona y 1-2 factores clave que más influyen.`;
  try {
    const res = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [{
          role: "system",
          content: sys
        }, {
          role: "user",
          content: user
        }]
      })
    });
    if (!res.ok) {
      console.error("AI gateway error", res.status, await res.text());
      return "No se pudo generar el análisis automático en este momento.";
    }
    const json = await res.json();
    return json.choices?.[0]?.message?.content?.trim() ?? "Análisis no disponible.";
  } catch (e) {
    console.error(e);
    return "No se pudo generar el análisis automático en este momento.";
  }
}
const valorarVivienda_createServerFn_handler = createServerRpc({
  id: "c3c5231f854084dceeff6c7283107c36ba0c8eb96a568467804938ba786e851e",
  name: "valorarVivienda",
  filename: "src/lib/valoracion.functions.ts"
}, (opts) => valorarVivienda.__executeServer(opts));
const valorarVivienda = createServerFn({
  method: "POST"
}).inputValidator((data) => Schema.parse(data)).handler(valorarVivienda_createServerFn_handler, async ({
  data
}) => {
  const zona = await buscarZona(data.codigoPostal, data.ciudad);
  const precioM2Zona = Number(zona.precio_m2_medio);
  const calc = calcularValoracion({
    metrosCuadrados: data.metrosCuadrados,
    precioM2Zona,
    estado: data.estado,
    extras: data.extras,
    planta: data.planta ?? void 0
  });
  const explicacion = await generarExplicacion({
    direccion: data.direccion,
    zona: zona.barrio,
    ciudad: zona.ciudad,
    m2: data.metrosCuadrados,
    estado: data.estado,
    extras: data.extras,
    valorMedio: calc.valorMedio,
    precioM2Ajustado: calc.precioM2Ajustado,
    precioM2Zona
  });
  const {
    data: row,
    error
  } = await supabaseAdmin.from("valoraciones").insert({
    direccion: data.direccion,
    ciudad: zona.ciudad,
    barrio: zona.barrio,
    codigo_postal: data.codigoPostal ?? zona.codigo_postal,
    metros_cuadrados: data.metrosCuadrados,
    habitaciones: data.habitaciones ?? null,
    banos: data.banos ?? null,
    planta: data.planta ?? null,
    ano_construccion: data.anoConstruccion ?? null,
    estado: data.estado,
    extras: data.extras,
    precio_m2_zona: precioM2Zona,
    valor_estimado_bajo: calc.valorBajo,
    valor_estimado_medio: calc.valorMedio,
    valor_estimado_alto: calc.valorAlto,
    explicacion_ia: explicacion
  }).select("id").single();
  if (error) {
    console.error("insert valoracion error", error);
  }
  return {
    id: row?.id ?? null,
    zona: {
      barrio: zona.barrio,
      ciudad: zona.ciudad,
      codigoPostal: zona.codigo_postal,
      precioM2: precioM2Zona
    },
    ...calc,
    explicacion
  };
});
const obtenerValoracion_createServerFn_handler = createServerRpc({
  id: "0569c2803ccef6f0c53e4ba230d1fb76f056f171e904a09f68dd9e04b72605d2",
  name: "obtenerValoracion",
  filename: "src/lib/valoracion.functions.ts"
}, (opts) => obtenerValoracion.__executeServer(opts));
const obtenerValoracion = createServerFn({
  method: "GET"
}).inputValidator((data) => objectType({
  id: stringType().uuid()
}).parse(data)).handler(obtenerValoracion_createServerFn_handler, async ({
  data
}) => {
  const {
    data: row,
    error
  } = await supabaseAdmin.from("valoraciones").select("*").eq("id", data.id).maybeSingle();
  if (error || !row) throw new Error("Valoración no encontrada");
  return row;
});
export {
  obtenerValoracion_createServerFn_handler,
  valorarVivienda_createServerFn_handler
};
