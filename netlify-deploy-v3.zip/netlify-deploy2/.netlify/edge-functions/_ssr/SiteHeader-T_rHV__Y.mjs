import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
function SiteHeader() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("header", { className: "sticky top-0 z-50 border-b border-border glass", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-7xl mx-auto px-6 h-16 flex items-center justify-between", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "flex items-center gap-2 group", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-8 bg-brand rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-2.5 bg-brand-foreground rounded-full group-hover:animate-pulse" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-bold text-lg tracking-tight", children: [
        "VALORA",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-accent", children: ".IA" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("nav", { className: "hidden md:flex items-center gap-8 text-sm font-medium text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", hash: "valorador", className: "hover:text-foreground transition-colors", children: "Valorador" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", hash: "como-funciona", className: "hover:text-foreground transition-colors", children: "Cómo funciona" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", hash: "inmobiliarias", className: "hover:text-foreground transition-colors", children: "Inmobiliarias" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        hash: "valorador",
        className: "bg-brand text-brand-foreground px-5 py-2.5 rounded-full text-sm font-semibold hover:opacity-90 transition-all",
        children: "Valorar gratis"
      }
    )
  ] }) });
}
export {
  SiteHeader as S
};
