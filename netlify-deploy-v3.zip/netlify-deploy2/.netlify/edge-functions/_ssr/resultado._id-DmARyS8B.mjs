import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { S as SiteHeader } from "./SiteHeader-T_rHV__Y.mjs";
import { S as SiteFooter } from "./SiteFooter-Bu54eDjk.mjs";
import { f as formatEUR } from "./valuation-CXMPruSL.mjs";
import { j as jspdf_node_minExports } from "../_libs/jspdf.mjs";
import { R as Route } from "./router-GROOodPV.mjs";
import "../_libs/seroval.mjs";
import { A as ArrowLeft, a as ShieldCheck, M as MapPin, S as Sparkles, T as TrendingUp, P as Phone, D as Download } from "../_libs/lucide-react.mjs";
import { m as motion, u as useMotionValue, a as useTransform, b as animate } from "../_libs/framer-motion.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "crypto";
import "async_hooks";
import "stream";
import "../_libs/isbot.mjs";
import "fs";
import "path";
import "../_libs/fflate.mjs";
import "../_libs/fast-png.mjs";
import "../_libs/iobuffer.mjs";
import "../_libs/pako.mjs";
import "../_libs/html2canvas.mjs";
import "../_libs/dompurify.mjs";
import "../_libs/canvg.mjs";
import "../_libs/core-js.mjs";
import "../_libs/babel__runtime.mjs";
import "../_libs/raf.mjs";
import "../_libs/performance-now.mjs";
import "../_libs/rgbcolor.mjs";
import "../_libs/svg-pathdata.mjs";
import "../_libs/stackblur-canvas.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "./server-C60K3KFC.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const ACCENT = [212, 95, 56];
const DARK = [20, 20, 24];
const MUTED = [110, 110, 120];
const LIGHT = [245, 243, 238];
const SUCCESS = [34, 139, 90];
const BORDER = [225, 222, 215];
function generarInformePDF(v) {
  const doc = new jspdf_node_minExports.jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 40;
  const medio = Number(v.valor_estimado_medio);
  const bajo = Number(v.valor_estimado_bajo);
  const alto = Number(v.valor_estimado_alto);
  const precioM2 = Math.round(medio / v.metros_cuadrados);
  const precioZona = Number(v.precio_m2_zona ?? 0);
  const diff = precioZona ? (precioM2 - precioZona) / precioZona * 100 : 0;
  const ref = v.id.slice(0, 8).toUpperCase();
  const fecha = new Date(v.created_at).toLocaleDateString("es-ES", {
    day: "2-digit",
    month: "long",
    year: "numeric"
  });
  let pageNum = 0;
  const totalPages = 4;
  const drawHeader = (subtitle) => {
    doc.setFillColor(...DARK);
    doc.rect(0, 0, W, 70, "F");
    doc.setTextColor(255, 255, 255);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.text("Valora.IA", M, 32);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(200, 200, 200);
    doc.text(subtitle, M, 50);
    doc.text(`Ref: ${ref}  ·  ${fecha}`, W - M, 50, { align: "right" });
  };
  const drawFooter = () => {
    const fy = H - 30;
    doc.setDrawColor(...BORDER);
    doc.setLineWidth(0.5);
    doc.line(M, fy - 12, W - M, fy - 12);
    doc.setFontSize(8);
    doc.setTextColor(...MUTED);
    doc.setFont("helvetica", "normal");
    doc.text(
      "Valoración estimada con metodología estadística e IA. No sustituye una tasación oficial homologada.",
      M,
      fy
    );
    doc.text(`Página ${pageNum} / ${totalPages}  ·  valora.ia`, W - M, fy, { align: "right" });
  };
  const newPage = (subtitle) => {
    if (pageNum > 0) doc.addPage();
    pageNum++;
    drawHeader(subtitle);
    drawFooter();
    return 100;
  };
  const sectionTitle = (text, y2) => {
    doc.setFillColor(...ACCENT);
    doc.rect(M, y2, 3, 16, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(13);
    doc.setTextColor(...DARK);
    doc.text(text, M + 12, y2 + 13);
    return y2 + 30;
  };
  const kv = (k, val, y2, x = M, w = W - M * 2) => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(...MUTED);
    doc.text(k, x, y2);
    doc.setTextColor(...DARK);
    doc.setFont("helvetica", "bold");
    doc.text(val, x + w, y2, { align: "right" });
    return y2 + 16;
  };
  let y = newPage("Informe profesional de valoración inmobiliaria");
  doc.setTextColor(...MUTED);
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text("INMUEBLE VALORADO", M, y);
  y += 18;
  doc.setTextColor(...DARK);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  const dirLines = doc.splitTextToSize(v.direccion, W - M * 2);
  doc.text(dirLines, M, y);
  y += dirLines.length * 22;
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(...MUTED);
  const ubic = [v.barrio, v.ciudad, v.codigo_postal].filter(Boolean).join(" · ");
  if (ubic) {
    doc.text(ubic, M, y);
    y += 20;
  }
  y += 10;
  doc.setFillColor(...DARK);
  doc.roundedRect(M, y, W - M * 2, 160, 12, 12, "F");
  doc.setTextColor(200, 200, 200);
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.text("VALOR ESTIMADO DE MERCADO", M + 24, y + 28);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(40);
  doc.setTextColor(255, 255, 255);
  doc.text(formatEUR(medio), M + 24, y + 78);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(11);
  doc.setTextColor(220, 220, 220);
  doc.text(
    `${precioM2.toLocaleString("es-ES")} €/m²  ·  ${v.metros_cuadrados} m² construidos`,
    M + 24,
    y + 100
  );
  doc.setDrawColor(80, 80, 90);
  doc.line(M + 24, y + 118, W - M - 24, y + 118);
  doc.setFontSize(9);
  doc.setTextColor(180, 180, 180);
  doc.text(`Rango bajo: ${formatEUR(bajo)}`, M + 24, y + 140);
  doc.text("Punto óptimo", W / 2, y + 140, { align: "center" });
  doc.text(`Rango alto: ${formatEUR(alto)}`, W - M - 24, y + 140, { align: "right" });
  y += 180;
  const kpiW = (W - M * 2 - 20) / 3;
  const kpis = [
    ["Precio zona", precioZona ? `${Math.round(precioZona).toLocaleString("es-ES")} €/m²` : "—", DARK],
    ["Diferencia", `${diff >= 0 ? "+" : ""}${diff.toFixed(1)}%`, diff >= 0 ? SUCCESS : ACCENT],
    ["Confianza", "Alta", SUCCESS]
  ];
  kpis.forEach(([k, val, color], i) => {
    const x = M + i * (kpiW + 10);
    doc.setFillColor(...LIGHT);
    doc.roundedRect(x, y, kpiW, 70, 10, 10, "F");
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(...MUTED);
    doc.text(k.toUpperCase(), x + 14, y + 22);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(18);
    doc.setTextColor(...color);
    doc.text(val, x + 14, y + 50);
  });
  y += 90;
  y = sectionTitle("Resumen ejecutivo", y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 70);
  const resumen = `Este informe presenta la valoración estimada del inmueble situado en ${v.direccion}${v.ciudad ? `, ${v.ciudad}` : ""}. La estimación se basa en datos del mercado inmobiliario español 2025, características técnicas declaradas de la vivienda, comparables del entorno y un modelo de inteligencia artificial entrenado con miles de transacciones reales. El valor de mercado se sitúa en ${formatEUR(medio)}, con un rango de confianza entre ${formatEUR(bajo)} y ${formatEUR(alto)}.`;
  const resLines = doc.splitTextToSize(resumen, W - M * 2);
  doc.text(resLines, M, y);
  y = newPage("Detalles del inmueble y análisis de zona");
  y = sectionTitle("Ficha técnica de la vivienda", y);
  const colW = (W - M * 2 - 20) / 2;
  const fichaL = [
    ["Superficie construida", `${v.metros_cuadrados} m²`],
    ["Habitaciones", v.habitaciones != null ? String(v.habitaciones) : "—"],
    ["Baños", v.banos != null ? String(v.banos) : "—"],
    ["Planta", v.planta != null ? String(v.planta) : "—"]
  ];
  const fichaR = [
    ["Año de construcción", v.ano_construccion != null ? String(v.ano_construccion) : "—"],
    ["Antigüedad", v.ano_construccion != null ? `${(/* @__PURE__ */ new Date()).getFullYear() - v.ano_construccion} años` : "—"],
    ["Estado", (v.estado ?? "—").replace("_", " ")],
    ["Tipo", "Vivienda residencial"]
  ];
  let yL = y, yR = y;
  fichaL.forEach(([k, val]) => {
    yL = kv(k, val, yL, M, colW);
  });
  fichaR.forEach(([k, val]) => {
    yR = kv(k, val, yR, M + colW + 20, colW);
  });
  y = Math.max(yL, yR) + 10;
  const extrasActivos = Object.entries(v.extras ?? {}).filter(([, x]) => x).map(([k]) => k);
  if (extrasActivos.length > 0) {
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(...MUTED);
    doc.text("EXTRAS Y CARACTERÍSTICAS", M, y);
    y += 16;
    let x = M;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    extrasActivos.forEach((e) => {
      const txt = "✓ " + e.charAt(0).toUpperCase() + e.slice(1);
      const w = doc.getTextWidth(txt) + 18;
      if (x + w > W - M) {
        x = M;
        y += 26;
      }
      doc.setFillColor(...LIGHT);
      doc.roundedRect(x, y - 12, w, 22, 11, 11, "F");
      doc.setTextColor(...DARK);
      doc.text(txt, x + 9, y + 3);
      x += w + 6;
    });
    y += 30;
  }
  y += 10;
  y = sectionTitle("Análisis del mercado en la zona", y);
  const zonaRows = [
    ["Ubicación", [v.barrio, v.ciudad].filter(Boolean).join(", ") || "—"],
    ["Código postal", v.codigo_postal ?? "—"],
    ["Precio medio €/m² en la zona", precioZona ? `${Math.round(precioZona).toLocaleString("es-ES")} €/m²` : "—"],
    ["Precio €/m² del inmueble", `${precioM2.toLocaleString("es-ES")} €/m²`],
    ["Diferencia respecto a la zona", `${diff >= 0 ? "+" : ""}${diff.toFixed(1)}%`],
    ["Tendencia interanual estimada", "+3.8%"],
    ["Liquidez de la zona", "Media-Alta"],
    ["Demanda de compra", "Alta"]
  ];
  zonaRows.forEach(([k, val]) => {
    y = kv(k, val, y);
  });
  y += 10;
  y = sectionTitle("Posicionamiento", y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 70);
  const posic = diff >= 0 ? `El inmueble se sitúa un ${diff.toFixed(1)}% por encima del precio medio de la zona, lo que sugiere un activo con características superiores o mejor estado de conservación frente a la media del entorno.` : `El inmueble se sitúa un ${Math.abs(diff).toFixed(1)}% por debajo del precio medio de la zona, lo que puede representar una oportunidad de inversión o reflejar características a mejorar (estado, planta, orientación).`;
  doc.text(doc.splitTextToSize(posic, W - M * 2), M, y);
  y = newPage("Metodología de cálculo y análisis IA");
  y = sectionTitle("Metodología aplicada", y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 70);
  const metodo = `La valoración combina tres fuentes:

1. Precio €/m² de referencia para la zona: obtenido mediante geocodificación del inmueble y enriquecimiento con datos de mercado actualizados (Idealista, Fotocasa, INE y registros oficiales).

2. Ajuste técnico por características: aplicamos coeficientes correctores por superficie, estado de conservación, planta, antigüedad y extras (terraza, ascensor, parking, etc.).

3. Modelo de IA generativa: un modelo de lenguaje analiza el conjunto de variables y contrasta el resultado con patrones del mercado para emitir un análisis cualitativo y validar el rango.`;
  const metLines = doc.splitTextToSize(metodo, W - M * 2);
  doc.text(metLines, M, y);
  y += metLines.length * 13 + 10;
  y = sectionTitle("Desglose del cálculo", y);
  const base = precioZona * v.metros_cuadrados;
  const ajuste = medio - base;
  y = kv("Precio base (€/m² zona × m²)", formatEUR(base), y);
  y = kv("Ajuste por estado y extras", `${ajuste >= 0 ? "+" : ""}${formatEUR(ajuste)}`, y);
  doc.setDrawColor(...BORDER);
  doc.line(M, y - 4, W - M, y - 4);
  y += 6;
  y = kv("Valor estimado de mercado", formatEUR(medio), y);
  y = kv("Rango inferior (–10%)", formatEUR(bajo), y);
  y = kv("Rango superior (+10%)", formatEUR(alto), y);
  y += 14;
  y = sectionTitle("Análisis con inteligencia artificial", y);
  doc.setFillColor(...LIGHT);
  const aiText = v.explicacion_ia || "Análisis no disponible.";
  const aiLines = doc.splitTextToSize(aiText, W - M * 2 - 24);
  const boxH = aiLines.length * 14 + 28;
  doc.roundedRect(M, y, W - M * 2, boxH, 10, 10, "F");
  doc.setFillColor(...ACCENT);
  doc.rect(M, y, 3, boxH, "F");
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(50, 50, 60);
  doc.text(aiLines, M + 16, y + 18);
  y = newPage("Recomendaciones y aspectos legales");
  y = sectionTitle("Recomendaciones para la venta", y);
  const recs = [
    ["Precio de salida sugerido", `Publicar entre ${formatEUR(medio)} y ${formatEUR(alto)} para captar interés rápido sin perder margen de negociación.`],
    ["Tiempo medio de venta", "Estimado entre 45 y 90 días en condiciones de mercado actuales."],
    ["Mejoras de bajo coste", "Pintura neutra, iluminación cálida y home staging básico aumentan el valor percibido entre un 3 % y un 7 %."],
    ["Documentación", "Reúne nota simple, certificado energético, IBI y, si aplica, ITE."],
    ["Canales recomendados", "Portales inmobiliarios principales + 1 agencia local con MLS."]
  ];
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  recs.forEach(([titulo, txt]) => {
    doc.setFillColor(...ACCENT);
    doc.circle(M + 4, y - 3, 3, "F");
    doc.setFont("helvetica", "bold");
    doc.setTextColor(...DARK);
    doc.text(titulo, M + 16, y);
    y += 14;
    doc.setFont("helvetica", "normal");
    doc.setTextColor(70, 70, 80);
    const ls = doc.splitTextToSize(txt, W - M * 2 - 16);
    doc.text(ls, M + 16, y);
    y += ls.length * 13 + 8;
  });
  y += 6;
  y = sectionTitle("Recomendaciones para la compra", y);
  const recsC = [
    "Negocia entre un 3 % y un 8 % sobre el precio publicado en función del estado.",
    "Solicita inspección técnica si la antigüedad supera los 30 años.",
    "Verifica cargas en el Registro de la Propiedad antes de la señal.",
    "Compara con al menos 3 inmuebles similares de la misma zona."
  ];
  doc.setFont("helvetica", "normal");
  doc.setFontSize(10);
  doc.setTextColor(60, 60, 70);
  recsC.forEach((r) => {
    doc.text("•", M, y);
    const ls = doc.splitTextToSize(r, W - M * 2 - 14);
    doc.text(ls, M + 12, y);
    y += ls.length * 13 + 4;
  });
  y += 10;
  y = sectionTitle("Aviso legal y limitaciones", y);
  doc.setFont("helvetica", "normal");
  doc.setFontSize(9);
  doc.setTextColor(...MUTED);
  const legal = `Este informe constituye una valoración estimada de carácter orientativo, generada mediante algoritmos estadísticos y modelos de inteligencia artificial a partir de los datos proporcionados por el usuario y de información pública del mercado inmobiliario español. No tiene validez como tasación oficial a efectos hipotecarios, judiciales, fiscales o de garantía, conforme a la Orden ECO/805/2003 y la normativa aplicable. Para una tasación homologada debe acudirse a una sociedad de tasación autorizada por el Banco de España. Valora.IA no se hace responsable de las decisiones tomadas en base a este documento. Los datos personales tratados se gestionan conforme al RGPD y a la LOPDGDD.`;
  const legalLines = doc.splitTextToSize(legal, W - M * 2);
  doc.text(legalLines, M, y);
  y += legalLines.length * 12 + 16;
  doc.setDrawColor(...BORDER);
  doc.line(M, y, M + 180, y);
  doc.setFontSize(9);
  doc.setTextColor(...DARK);
  doc.setFont("helvetica", "bold");
  doc.text("Valora.IA", M, y + 14);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(...MUTED);
  doc.text("Plataforma de valoración inmobiliaria con IA", M, y + 28);
  doc.save(`Valoracion-${ref}-${v.direccion.slice(0, 30).replace(/[^\w]+/g, "-")}.pdf`);
}
function AnimatedEUR({
  value
}) {
  const mv = useMotionValue(0);
  const rounded = useTransform(mv, (v) => formatEUR(Math.round(v)));
  reactExports.useEffect(() => {
    const controls = animate(mv, value, {
      duration: 1.4,
      ease: [0.16, 1, 0.3, 1]
    });
    return controls.stop;
  }, [value, mv]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(motion.span, { children: rounded });
}
function ResultadoPage() {
  const {
    v
  } = Route.useLoaderData();
  const medio = Number(v.valor_estimado_medio);
  const bajo = Number(v.valor_estimado_bajo);
  const alto = Number(v.valor_estimado_alto);
  const precioM2 = Math.round(medio / v.metros_cuadrados);
  const precioM2Zona = Number(v.precio_m2_zona ?? 0);
  const diffPct = precioM2Zona ? (precioM2 - precioM2Zona) / precioM2Zona * 100 : 0;
  const extras = v.extras ?? {};
  const extrasActivos = Object.entries(extras).filter(([, x]) => x).map(([k]) => k);
  const range = alto - bajo;
  const pos = range > 0 ? (medio - bajo) / range * 100 : 50;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-screen flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteHeader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: "flex-1 px-6 py-10 md:py-14", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-6xl mx-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/", className: "inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "size-4" }),
        " Nueva valoración"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-5 gap-6 lg:gap-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "lg:col-span-3 space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card rounded-3xl p-8 md:p-10 border border-border shadow-[var(--shadow-card)] animate-fade-up", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-start justify-between mb-6 flex-wrap gap-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-success/10 text-success text-xs font-bold uppercase tracking-wider", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShieldCheck, { className: "size-3" }),
                "Valoración estimada"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mt-3 text-sm text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "size-4" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: v.direccion })
              ] })
            ] }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-5xl md:text-7xl font-bold tracking-tighter bg-gradient-to-br from-foreground to-foreground/60 bg-clip-text text-transparent", children: /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatedEUR, { value: medio }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-muted-foreground mt-2", children: [
              precioM2.toLocaleString("es-ES"),
              " €/m² · ",
              v.metros_cuadrados,
              " m²",
              v.barrio && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                " · ",
                v.barrio,
                ", ",
                v.ciudad
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-[10px] font-bold uppercase tracking-widest text-muted-foreground", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Rango bajo" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Punto óptimo" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Rango alto" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-3 bg-secondary rounded-full overflow-visible", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-y-0 left-[8%] right-[8%] rounded-full bg-gradient-to-r from-secondary via-accent/50 to-secondary" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { className: "absolute top-1/2 -translate-y-1/2 size-5 rounded-full bg-accent ring-4 ring-card shadow-lg", initial: {
                  left: "0%",
                  scale: 0
                }, animate: {
                  left: `calc(${pos}% - 10px)`,
                  scale: 1
                }, transition: {
                  duration: 1.2,
                  delay: 0.3,
                  ease: [0.16, 1, 0.3, 1]
                } })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-sm font-semibold", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatEUR(bajo) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-accent", children: formatEUR(medio) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: formatEUR(alto) })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 divide-x divide-border mt-10 -mx-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Precio zona" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold mt-1", children: precioM2Zona ? `${Math.round(precioM2Zona).toLocaleString("es-ES")} €/m²` : "—" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Diferencia" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `font-bold mt-1 ${diffPct >= 0 ? "text-success" : "text-destructive"}`, children: [
                  diffPct >= 0 ? "+" : "",
                  diffPct.toFixed(1),
                  "%"
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: "Confianza" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-bold mt-1 text-success", children: "Alta" })
              ] })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-accent/5 border border-accent/15 rounded-3xl p-6 md:p-8 animate-fade-up", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "size-7 bg-accent rounded-full grid place-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "size-3.5 text-accent-foreground" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-bold", children: "Análisis con inteligencia artificial" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-foreground/80 leading-relaxed text-lg", children: v.explicacion_ia || "Análisis no disponible." })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "lg:col-span-2 space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card border border-border rounded-3xl p-6 animate-fade-up", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4", children: "Detalle de la vivienda" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("dl", { className: "space-y-3 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "Superficie", v: `${v.metros_cuadrados} m²` }),
              v.habitaciones != null && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "Habitaciones", v: String(v.habitaciones) }),
              v.banos != null && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "Baños", v: String(v.banos) }),
              v.planta != null && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "Planta", v: String(v.planta) }),
              v.ano_construccion != null && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "Año", v: String(v.ano_construccion) }),
              v.estado && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "Estado", v: String(v.estado).replace("_", " ") }),
              v.codigo_postal && /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { k: "CP", v: String(v.codigo_postal) })
            ] }),
            extrasActivos.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-px bg-border my-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3", children: "Extras" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: extrasActivos.map((x) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-full text-xs font-semibold bg-secondary capitalize", children: x }, x)) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card border border-border rounded-3xl p-6 animate-fade-up", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "text-xs font-bold uppercase tracking-wider text-muted-foreground mb-4 flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "size-4" }),
              " Tendencia de la zona"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-bold text-success", children: "+3.8%" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground mt-1", children: "Variación interanual estimada" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-brand text-brand-foreground rounded-3xl p-6 animate-fade-up", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "font-bold mb-2", children: "¿Quieres vender?" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-brand-foreground/70 text-sm mb-5", children: "Conecta con inmobiliarias especializadas en tu barrio y recibe ofertas." }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { className: "w-full bg-brand-foreground text-brand py-3 rounded-xl font-bold flex items-center justify-center gap-2 hover:opacity-90", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "size-4" }),
              " Obtener ofertas"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => generarInformePDF(v), className: "w-full mt-2 border border-brand-foreground/20 text-brand-foreground py-3 rounded-xl font-semibold flex items-center justify-center gap-2 hover:bg-brand-foreground/5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "size-4" }),
              " Descargar informe PDF"
            ] })
          ] })
        ] })
      ] })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SiteFooter, {})
  ] });
}
function Row({
  k,
  v
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("dt", { className: "text-muted-foreground", children: k }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("dd", { className: "font-semibold capitalize", children: v })
  ] });
}
export {
  ResultadoPage as component
};
